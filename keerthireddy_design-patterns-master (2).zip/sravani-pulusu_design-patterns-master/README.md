Design patterns
